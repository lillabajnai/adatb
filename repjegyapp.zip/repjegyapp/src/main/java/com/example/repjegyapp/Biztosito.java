package com.example.repjegyapp;

public class Biztosito {
    private int id;
    //TODO: private String leiras;

    public Biztosito() {
    }

    public Biztosito(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
