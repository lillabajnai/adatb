package com.example.repjegyapp;

public class Ertekeles {

    private  String username;
    private int jaratszam;
    private int ertekeles;

    public Ertekeles() {
    }

    @Override
    public String toString() {
        return  username + " " + jaratszam + " " + ertekeles ;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getJaratszam() {
        return jaratszam;
    }

    public void setJaratszam(int jaratszam) {
        this.jaratszam = jaratszam;
    }

    public int getErtekeles() {
        return ertekeles;
    }

    public void setErtekeles(int ertekeles) {
        this.ertekeles = ertekeles;
    }

    public Ertekeles(String username, int jaratszam, int ertekeles) {
        this.username = username;
        this.jaratszam = jaratszam;
        this.ertekeles = ertekeles;
    }
}
