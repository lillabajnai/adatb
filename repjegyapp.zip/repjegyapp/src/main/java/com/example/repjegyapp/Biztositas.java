package com.example.repjegyapp;

import java.util.Date;

public class Biztositas {
    private int id;
    private  int price;
    private Date date;
    private int biztositoID;

    public Biztositas() {
    }

    public Biztositas(int id, int price, Date date, int biztositoID) {
        this.id = id;
        this.price = price;
        this.date = date;
        this.biztositoID = biztositoID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getBiztositoID() {
        return biztositoID;
    }

    public void setBiztositoID(int biztositoID) {
        this.biztositoID = biztositoID;
    }
}
