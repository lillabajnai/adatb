package com.example.repjegyapp;

public class Jarat {
    private int jaratszam;
    private boolean etkezes;
    private int szabadhely;
    private String indulas;
    private String erkezes;
    private String honnan;
    private String hova;
    private String legitarsasag;

    public Jarat() {
    }

    public String getHonnan() {
        return honnan;
    }

    public void setHonnan(String honnan) {
        this.honnan = honnan;
    }

    public String getHova() {
        return hova;
    }

    public void setHova(String hova) {
        this.hova = hova;
    }

    public Jarat(int jaratszam, boolean etkezes, int szabadhely, String indulas, String erkezes, String honnan, String hova, String legitarsasag) {
        this.jaratszam = jaratszam;
        this.etkezes = etkezes;
        this.szabadhely = szabadhely;
        this.indulas = indulas;
        this.erkezes = erkezes;
        this.honnan = honnan;
        this.hova = hova;
        this.legitarsasag = legitarsasag;
    }

    public int getJaratszam() {
        return jaratszam;
    }

    public void setJaratszam(int jaratszam) {
        this.jaratszam = jaratszam;
    }

    public boolean isEtkezes() {
        return etkezes;
    }

    public void setEtkezes(boolean etkezes) {
        this.etkezes = etkezes;
    }

    public int getSzabadhely() {
        return szabadhely;
    }

    public void setSzabadhely(int szabadhely) {
        this.szabadhely = szabadhely;
    }

    public String getIndulas() {
        return indulas;
    }

    public void setIndulas(String indulas) {
        this.indulas = indulas;
    }

    public String getErkezes() {
        return erkezes;
    }

    public void setErkezes(String erkezes) {
        this.erkezes = erkezes;
    }

    public String getLegitarsasag() {
        return legitarsasag;
    }

    public void setLegitarsasag(String legitarsasag) {
        this.legitarsasag = legitarsasag;
    }
}
