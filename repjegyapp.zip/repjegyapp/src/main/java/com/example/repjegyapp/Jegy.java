package com.example.repjegyapp;

public class Jegy {

    private int id;
    private int price;
    private int atszallas;
    private String username;
    private int jaratszam;
    private int Felnott; // true-> Felnott jegy false-> Gyerek jegy

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAtszallas() {
        return atszallas;
    }

    public void setAtszallas(int atszallas) {
        this.atszallas = atszallas;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String felhasznalonev) {
        this.username = felhasznalonev;
    }

    public int getJaratszam() {
        return jaratszam;
    }

    public void setJaratszam(int jaratszam) {
        this.jaratszam = jaratszam;
    }

    public int getFelnott() {
        return Felnott;
    }

    public void getFelnott(int felnott) {
        Felnott = felnott;
    }

    public Jegy() {
    }

    public Jegy(int id, int price, int atszallas, String username, int jaratszam, int felnott) {
        this.id = id;
        this.price = price;
        this.atszallas = atszallas;
        this.username = username;
        this.jaratszam = jaratszam;
        this.Felnott = felnott;
    }
}
