package com.example.repjegyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;
import java.util.List;

public class HelloController {
    @FXML private ComboBox idBiztKatAdd;
    @FXML private TextField ertekelesErtekelesUpdate;
    @FXML private ComboBox usernameErtekelesUpdate;
    @FXML private ComboBox jaratszamErtekelesUpdate;
    @FXML private ComboBox idBiztositasDelete;
    @FXML private TextField kategoriaBiztKatAdd;
    @FXML private ComboBox nameLegitarsUpdate;
    @FXML private TextField telephelyLegitarsUpdate;
    @FXML private TextField ownerLegitarsUpdate;
    @FXML private ComboBox jaratDelete;
    @FXML private ComboBox jegyekDel;
    @FXML private TextField idBiztositoAdd;
    @FXML private ComboBox biztostasidUtasAdd;
    @FXML private TextField emailUtasAdd;
    @FXML private TextField passwordUtasAdd;
    @FXML private TextField usernameUtasAdd;
    @FXML private TableView tv1;
    @FXML private TableView tv2;
    @FXML private TableView tv3;
    @FXML private TableView tv4;
    @FXML private TableView tv5;
    @FXML private TableView tv6;
    @FXML private TableView tv7;
    @FXML private TableView tv8;

    private DAO dao;
    private List<Integer> biztIDs = new ArrayList<>();
    @FXML
    public void initialize(){
        dao = new DAO();

        TableColumn usernameCol = new TableColumn("felhasznalonev");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        TableColumn emailCol = new TableColumn("email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        TableColumn passwordCol = new TableColumn("jelszo");
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
        TableColumn biztositoIDCol = new TableColumn("biztositasid");
        biztositoIDCol.setCellValueFactory(new PropertyValueFactory<>("biztositasID"));
        tv1.getColumns().addAll(usernameCol,emailCol,passwordCol,biztositoIDCol);

        TableColumn nameCol = new TableColumn("Név");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        TableColumn ownerCol = new TableColumn("Tulajdonos");
        ownerCol.setCellValueFactory(new PropertyValueFactory<>("owner"));
        TableColumn telephelyCol = new TableColumn("Telephely");
        telephelyCol.setCellValueFactory(new PropertyValueFactory<>("telephely"));
        tv2.getColumns().addAll(nameCol,ownerCol,telephelyCol);

        TableColumn idCol = new TableColumn("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn priceCol = new TableColumn("Ár");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        TableColumn atszallasCol = new TableColumn("Atszallas");
        atszallasCol.setCellValueFactory(new PropertyValueFactory<>("atszallas"));
        TableColumn usernameJCol = new TableColumn("Felhasznalonev");
        usernameJCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        TableColumn jaratszamCol = new TableColumn("Jaratszam");
        jaratszamCol.setCellValueFactory(new PropertyValueFactory<>("jaratszam"));
        TableColumn felnottCol = new TableColumn("Felnott-e");
        felnottCol.setCellValueFactory(new PropertyValueFactory<>("Felnott"));
        tv3.getColumns().addAll(idCol,priceCol,atszallasCol,usernameJCol,jaratszamCol,felnottCol);

        TableColumn jaratszamJCol = new TableColumn("Jaratszam");
        jaratszamJCol.setCellValueFactory(new PropertyValueFactory<>("jaratszam"));
        TableColumn etkezesCol = new TableColumn("Etkezes");
        etkezesCol.setCellValueFactory(new PropertyValueFactory<>("etkezes"));
        TableColumn szabadhelyCol = new TableColumn("Szabad helyek");
        szabadhelyCol.setCellValueFactory(new PropertyValueFactory<>("szabadhely"));
        TableColumn indulasCol = new TableColumn("Indulas");
        indulasCol.setCellValueFactory(new PropertyValueFactory<>("indulas"));
        TableColumn erkezesCol = new TableColumn("Erkezes");
        erkezesCol.setCellValueFactory(new PropertyValueFactory<>("erkezes"));
        TableColumn honnanCol = new TableColumn("Honnan");
        honnanCol.setCellValueFactory(new PropertyValueFactory<>("honnan"));
        TableColumn hovaCol = new TableColumn("Hova");
        hovaCol.setCellValueFactory(new PropertyValueFactory<>("hova"));
        TableColumn legitarsasagCol = new TableColumn("Legitarsasag");
        legitarsasagCol.setCellValueFactory(new PropertyValueFactory<>("legitarsasag"));
        tv4.getColumns().addAll(jaratszamJCol,etkezesCol,szabadhelyCol,indulasCol,erkezesCol,honnanCol,hovaCol,legitarsasagCol);

        TableColumn usernameECol = new TableColumn("Felhasznalonev");
        usernameECol.setCellValueFactory(new PropertyValueFactory<>("username"));
        TableColumn jaratszamECol = new TableColumn("Jaratszam");
        jaratszamECol.setCellValueFactory(new PropertyValueFactory<>("jaratszam"));
        TableColumn ertekelesCol = new TableColumn("Ertekeles");
        ertekelesCol.setCellValueFactory(new PropertyValueFactory<>("ertekeles"));
        tv5.getColumns().addAll(usernameECol, jaratszamECol,ertekelesCol);

        TableColumn idBCol = new TableColumn("ID");
        idBCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        tv6.getColumns().addAll(idBCol);

        TableColumn idBiZCol = new TableColumn("ID");
        idBiZCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn priceBCol = new TableColumn("Ar");
        priceBCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        TableColumn dateCol = new TableColumn("Datum");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        TableColumn biztositoICol = new TableColumn("Biztosito ID");
        biztositoICol.setCellValueFactory(new PropertyValueFactory<>("biztositoID"));
        tv7.getColumns().addAll(idBiZCol,priceBCol,dateCol,biztositoICol);

        TableColumn idCATCol = new TableColumn("ID");
        idCATCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn categoryCol = new TableColumn("Kategoria");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        tv8.getColumns().addAll(idCATCol,categoryCol);

        System.out.println("INIT");
    }

    public void pressUtasok(ActionEvent e){
        System.out.println("-------------Utasok-------------");
        ArrayList<Utas> utasok = dao.readUtas();

        tv1.getItems().clear();
        biztostasidUtasAdd.getItems().clear();

        for(Utas utas: utasok){
            System.out.println(utas);
            tv1.getItems().add(utas);
            biztostasidUtasAdd.getItems().add(utas.getBiztositasID());
        }
    }
    public void pressLegitarsasagok(ActionEvent e){
        System.out.println("-------------Legitarsasagok-------------");
        ArrayList<Legitarsasag> legitarsasagok = dao.readLegitarsasag();
        tv2.getItems().clear();
        nameLegitarsUpdate.getItems().clear();
        for(Legitarsasag legitarsasag: legitarsasagok){
            tv2.getItems().add(legitarsasag);
            nameLegitarsUpdate.getItems().add(legitarsasag.getName());
        }
    }
    public void pressJegyek(ActionEvent e){
        System.out.println("-------------Jegyek-------------");
        ArrayList<Jegy> jegyek = dao.readJegy();
        tv3.getItems().clear();
        jegyekDel.getItems().clear();
        for(Jegy jegy: jegyek){
            tv3.getItems().add(jegy);
            jegyekDel.getItems().add(jegy.getId());
        }
    }
    public void pressJaratok(ActionEvent e){
        System.out.println("-------------Jaratok-------------");
        ArrayList<Jarat> jaratok = dao.readJarat();
        tv4.getItems().clear();
        jaratDelete.getItems().clear();
        for(Jarat jarat: jaratok){
            tv4.getItems().add(jarat);
            jaratDelete.getItems().add(jarat.getJaratszam());
        }
    }
    public void pressErtekelesek(ActionEvent e){
        System.out.println("-------------Ertekelesek-------------");
        ArrayList<Ertekeles> ertekelesek = dao.readErtekeles();
        tv5.getItems().clear();
        usernameErtekelesUpdate.getItems().clear();
        jaratszamErtekelesUpdate.getItems().clear();
        for(Ertekeles ertekeles: ertekelesek){
            tv5.getItems().add(ertekeles);
            usernameErtekelesUpdate.getItems().add(ertekeles.getUsername());
            jaratszamErtekelesUpdate.getItems().add(ertekeles.getJaratszam());
        }
    }
    public void pressBiztositok(ActionEvent e){
        System.out.println("-------------Biztositok-------------");
        ArrayList<Biztosito> biztositok = dao.readBiztosito();
        tv6.getItems().clear();
        for(Biztosito biztosito:biztositok){
            tv6.getItems().add(biztosito);
        }
    }
    public void pressBiztositasok(ActionEvent e){
        System.out.println("-------------Biztositasok-------------");
        ArrayList<Biztositas> biztositasok = dao.readBiztositas();
        tv7.getItems().clear();
        idBiztositasDelete.getItems().clear();
        idBiztKatAdd.getItems().clear();
        for(Biztositas biztositas:biztositasok){
            tv7.getItems().add(biztositas);
            idBiztositasDelete.getItems().add(biztositas.getId());
            idBiztKatAdd.getItems().add(biztositas.getId());
        }
    }
    public void pressBiztositasCat(ActionEvent e){
        System.out.println("-------------BiztositasCat-------------");
        ArrayList<BiztositasCategories> biztcats = dao.readBiztCat();
        tv8.getItems().clear();

        for(BiztositasCategories bc: biztcats){
            tv8.getItems().add(bc);
        }
    }


    public void addUtas(ActionEvent actionEvent) {
        System.out.println("__________ADDUTAS___________");
        Utas utas = new Utas(
            usernameUtasAdd.getText(),
                emailUtasAdd.getText(),
                passwordUtasAdd.getText(),
                DAO.parseInt(biztostasidUtasAdd.getValue().toString())
        );
        dao.addUtas(utas);
        pressUtasok(actionEvent);
    }
    public void addBiztosito(ActionEvent actionEvent){
        System.out.println("__________ADDBIZTOSITO___________");
        Biztosito biztosito=new Biztosito(DAO.parseInt(idBiztositoAdd.getText()));
        dao.addBiztosito(biztosito);
        pressBiztositok(actionEvent);
    }
    public void addBiztKat(ActionEvent actionEvent) {
        System.out.println("__________ADDBIZTKAT___________");
        BiztositasCategories biztkat = new BiztositasCategories(
                dao.parseInt(idBiztKatAdd.getValue().toString()),
                kategoriaBiztKatAdd.getText());
        dao.addBiztCat(biztkat);
        pressBiztositasCat(actionEvent);
    }

    public void deleteJegy(ActionEvent actionEvent) {
        System.out.println("__________DELETEJEGY___________");
        dao.deleteJegy(Integer.parseInt(jegyekDel.getValue().toString()));
        pressJegyek(actionEvent);
    }
    public void deleteBiztositas(ActionEvent actionEvent) {
        System.out.println("__________DELETEBIZTOSITAS___________");
        dao.deleteBiztositas(dao.parseInt(idBiztositasDelete.getValue().toString()));
        pressBiztositasok(actionEvent);
    }
    public void deleteJarat(ActionEvent actionEvent) {
        System.out.println("__________DELETEJARAT___________");
        dao.deleteJarat(dao.parseInt(jaratDelete.getValue().toString()));
        pressJaratok(actionEvent);
    }

    public void updateLegitarsasag(ActionEvent actionEvent) {
        System.out.println("__________UPDATELEGITARSASAG___________");
        Legitarsasag legitarsasag = new Legitarsasag(
                nameLegitarsUpdate.getValue().toString(),
                ownerLegitarsUpdate.getText(),
                telephelyLegitarsUpdate.getText());
        dao.updateLegitarsasag(legitarsasag);
        pressLegitarsasagok(actionEvent);
    }
    public void updateErtekeles(ActionEvent actionEvent) {
        //TODO: CHECK IF ERTEKELES EXIST
        System.out.println("__________UPDATEERTEKELES___________");
        Ertekeles ertekeles = new Ertekeles(
                usernameErtekelesUpdate.getValue().toString(),
                dao.parseInt(jaratszamErtekelesUpdate.getValue().toString()),
                dao.parseInt(ertekelesErtekelesUpdate.getText()));
        dao.updateErtekeles(ertekeles);
        pressErtekelesek(actionEvent);
    }


}