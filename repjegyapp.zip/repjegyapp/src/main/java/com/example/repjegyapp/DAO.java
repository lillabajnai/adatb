package com.example.repjegyapp;

import oracle.jdbc.pool.OracleDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DAO {
    private ResultSet rs;
    private Statement stmt;
    private OracleDataSource ods;
    private final String usrname = "system";
    private final String pwd = "oracle";

    public DAO(){
        try {
            ods = new OracleDataSource();
            Class.forName ("oracle.jdbc.OracleDriver");
            ods.setURL("jdbc:oracle:thin:@localhost:1521:xe");
        } catch ( Exception ex ) {
            ex.printStackTrace();
        }
    }

    public boolean addUtas(Utas utas){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "INSERT INTO UTAS (felhasznalonev, email, jelszo, biztositasid) " +
                    "VALUES ('"+utas.getUsername()+"', '"+utas.getEmail()+"', '"+utas.getPassword()+"', "+utas.getBiztositasID()+")";
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public boolean addBiztosito(Biztosito biztosito){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "INSERT INTO BIZTOSITO (id) VALUES ("+biztosito.getId()+")";
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean addBiztCat(BiztositasCategories  biztcat){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "INSERT INTO BIZTOSITAS_KATEGORIAK (id, kategoria) VALUES ("+biztcat.getId()+", '"+biztcat.getCategory()+"')";
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean deleteJarat(int jaratszam){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "delete from JARAT where jaratszam="+jaratszam;
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean deleteBiztositas(int id){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "delete from BIZTOSITAS where id="+id;
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean deleteJegy(int id){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "delete from JEGY where id ="+id;
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateLegitarsasag(Legitarsasag legitarsasag){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "update LEGITARSASAG set tulajdonos='"
                    +legitarsasag.getOwner()+"', telephely='"+legitarsasag.getTelephely()+"' where neve='"+legitarsasag.getName()+"'";
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean updateErtekeles(Ertekeles ertekeles){
        try{
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "update ERTEKEL set ertekeles="+ertekeles.getErtekeles()+" where felhasznalonev='"+ertekeles.getUsername()+"' and jaratszam="+ertekeles.getJaratszam();
            rs = stmt.executeQuery(sql);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

//------------------------------READS--------------------------------------

    public ArrayList<Utas> readUtas(){
        ArrayList<Utas> utasok = new ArrayList<Utas>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from utas";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Utas utas = new Utas(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4));
                utasok.add(utas);
                System.out.println(utas);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return utasok;
    }

    public ArrayList<Legitarsasag> readLegitarsasag(){
        ArrayList<Legitarsasag> legitarsasagok = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from legitarsasag";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Legitarsasag legitarsasag = new Legitarsasag(rs.getString(1),rs.getString(2),rs.getString(3));
                legitarsasagok.add(legitarsasag);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return legitarsasagok;
    }

    public ArrayList<Jegy> readJegy(){
        ArrayList<Jegy> jegyek = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from jegy";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Jegy jegy = new Jegy(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(5),rs.getInt(6),rs.getInt(4));
                jegyek.add(jegy);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return jegyek;
    }

    public ArrayList<Jarat> readJarat(){
        ArrayList<Jarat> jaratok = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from jarat";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Jarat jarat = new Jarat(rs.getInt(1),rs.getBoolean(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
                jaratok.add(jarat);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return jaratok;
    }

    public ArrayList<Ertekeles> readErtekeles(){
        ArrayList<Ertekeles> ertekelesek = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from ertekel";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Ertekeles ertekeles = new Ertekeles(rs.getString(1),rs.getInt(2),rs.getInt(3));
                ertekelesek.add(ertekeles);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return ertekelesek;
    }

    public ArrayList<Biztosito> readBiztosito(){
        ArrayList<Biztosito> biztositok = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from biztosito";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Biztosito biztosito = new Biztosito(rs.getInt(1));
                biztositok.add(biztosito);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return biztositok;
    }

    public ArrayList<Biztositas> readBiztositas(){
        ArrayList<Biztositas> biztositasok = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from biztositas";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                Biztositas biztositas = new Biztositas(rs.getInt(1),rs.getInt(2),rs.getDate(3),rs.getInt(4));
               biztositasok.add(biztositas);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return biztositasok;
    }

    public ArrayList<BiztositasCategories> readBiztCat(){
        ArrayList<BiztositasCategories> biztositasCategories = new ArrayList<>();
        try {
            Connection conn = ods.getConnection(usrname,pwd);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "select * from biztositas_kategoriak";
            rs = stmt.executeQuery(sql);
            while (rs.next()){
                BiztositasCategories bc = new BiztositasCategories(rs.getInt(1),rs.getString(2));
                biztositasCategories.add(bc);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return biztositasCategories;
    }

    public static Integer parseInt(String s){
        Integer i = null;
        try{i=Integer.parseInt(s);}catch(NumberFormatException n){}
        return i;
    }

}
