package com.example.repjegyapp;

public class Legitarsasag {
    private String name;
    private String owner;
    private String telephely;

    public Legitarsasag(String name, String owner, String telephely) {
        this.name = name;
        this.owner = owner;
        this.telephely = telephely;
    }

    public Legitarsasag() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getTelephely() {
        return telephely;
    }

    public void setTelephely(String telephely) {
        this.telephely = telephely;
    }
}
