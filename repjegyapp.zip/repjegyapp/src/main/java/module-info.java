module com.example.repjegyapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires java.naming;
    requires ojdbc8;

    opens com.example.repjegyapp to javafx.fxml;
    exports com.example.repjegyapp;
}